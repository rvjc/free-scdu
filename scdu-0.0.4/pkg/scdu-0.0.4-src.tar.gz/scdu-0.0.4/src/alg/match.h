// Copyright 2015-2016 RVJ Callanan.
// Released under the GNU General Public License (Version 3).

#if !defined MATCH_H

    #define MATCH_H

    extern bool isMatchCS(const char* pat, const char* str);
    extern bool isMatchCI(const char* pat, const char* str);

#endif // PATTERN_H

// EOF