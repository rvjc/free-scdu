// Copyright 2015-2016 RVJ Callanan.
// Released under the GNU General Public License (Version 3).

#if !defined SHOW_H

    #define SHOW_H

    extern void show();

#endif // SHOW_H

// EOF