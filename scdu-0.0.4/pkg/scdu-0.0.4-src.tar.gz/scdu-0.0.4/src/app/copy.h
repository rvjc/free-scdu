// Copyright 2015-2016 RVJ Callanan.
// Released under the GNU General Public License (Version 3).

#if !defined COPY_H

    #define COPY_H

    extern void copy();

#endif // COPY_H

// EOF