// Copyright 2015-2016 RVJ Callanan.
// Released under the GNU General Public License (Version 3).

#include "../core/core.h"

#include "info.h"

void info()
{
    outR("action not yet implemented");
}

// EOF