// Copyright 2015-2016 RVJ Callanan.
// Released under the GNU General Public License (Version 3).

#if !defined DUMP_H

    #define DUMP_H

    extern void view();

#endif // DUMP_H

// EOF