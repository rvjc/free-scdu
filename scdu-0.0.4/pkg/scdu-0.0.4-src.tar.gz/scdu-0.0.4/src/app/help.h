// Copyright 2015-2016 RVJ Callanan.
// Released under the GNU General Public License (Version 3).

#if !defined HELP_H

    #define HELP_H

    extern void help();

#endif // HELP_H

// EOF