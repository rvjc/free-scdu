// Copyright 2015-2016 RVJ Callanan.
// Released under the GNU General Public License (Version 3).

#if !defined INFO_H

    #define INFO_H

    extern void info();

#endif // INFO_H

// EOF